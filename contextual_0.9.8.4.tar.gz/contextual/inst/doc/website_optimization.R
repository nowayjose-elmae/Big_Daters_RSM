## ----setup, include = FALSE, cache = TRUE-------------------------------------
knitr::opts_chunk$set(
  fig.pos = 'H',
  collapse = TRUE,
  comment = "#>"
)

