# offline-parameter-tuning
Code for the offline paramater tuning paper (submitted to IDA 2020)

For the replications of the plots, see demo_lif_bandit.R and demo_tbl_bandit.R
