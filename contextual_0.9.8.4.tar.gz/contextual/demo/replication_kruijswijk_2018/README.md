# Bandits with dependent observations

Code for replication plots of the paper "Exploiting Nested Data Structures in Multi-Armed Bandits" (submitted to PLOS One).

Run file 2a and 2b to generate the plots for the simulation study. Do note that running these can take quite a while - especially for the partial pooling version for Thompson sampling - so use with care.

Run file 3 to generate the plots for the empirical study using the supplied .csv file.
