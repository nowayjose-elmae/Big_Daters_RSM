contextual 0.9.8.4
==================

* Minor documentation updates.
* Fix for Exp3 bug (thanks, @leferrad)
* Cleanup of propensity score related code (thanks again, @leferrad)
* Updated tests.


contextual 0.9.8.3
==================

* Tested and confirmed to be R 4.0.0 proof.
* Minor documentation updates.
* Now correctly restores global seed on completing a simulation (thanks, @pstansell)


contextual 0.9.8.2
==================

* Minor documentation update
* Minor refactoring: Private utility functions moved from the History to the Plot class.

contextual 0.9.8.1
==================

* Specified previous version of set.seed sampler with RNGversion() calls

contextual 0.9.8
================

* Major update
* API change for offline Bandits
* Fixes inverse propensity score weighting
* Documentation updates
* Additional demo scripts

contextual 0.9.1
================

* First CRAN release 

contextual 0.9.0
================

* CRAN Submission 
